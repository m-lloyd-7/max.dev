import requests
import pandas as pd
import numpy as np
import io
import json
import datetime as dt
from typing import List, Tuple, Dict
from py_max.py_utils.error_logging import ErrorLogger

logger = ErrorLogger(
    __name__,
    "C:/Users/User/dev/max-dev/max_development/stock_project/stock_project/error_logs/stock_stripper_log.log",
)


class MarketMetrics:
    high: str = "regularMarketDayHigh"
    low: str = "regularMarketDayLow"
    volume: str = "regularMarketVolume"
    price: str = "regularMarketPrice"
    instrument_type: str = "instrumentType"
    currency: str = "currency"
    symbol: str = "symbol"
    exchange_name: str = "exchangeName"
    as_at_time: str = "regularMarketTime"


class StockGrabber:
    """
    Class object for reading stock market data from Yahoo finance
    """

    def __init__(
        self, ticker: str, from_date_dt: dt.datetime, to_date_dt: dt.datetime
    ) -> None:
        # Static data initialisation
        self.header = {
            "user-agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:109.0) Gecko/20100101 Firefox/114.0"
        }
        self.ticker = ticker
        self.from_date_dt = from_date_dt
        self.to_date_dt = to_date_dt
        self.from_date = round(dt.datetime.timestamp(self.from_date_dt))
        self.to_date = round(dt.datetime.timestamp(self.to_date_dt))
        self._url = f"https://query1.finance.yahoo.com/v8/finance/chart/{self.ticker}?symbol={self.ticker}&period1={self.from_date}&period2={self.to_date}&useYfid=true&interval=1m&includePrePost=true&events=div%7Csplit%7Cearn&lang=en-US&region=US&crumb=azr2X8.O.Sf&corsDomain=finance.yahoo.com"

    def __enter__(self) -> Dict:
        # Request execution
        self.request = requests.get(self._url, headers=self.header)
        self._decode_format = "ISO-8859-1"
        self.content = self.request.content

        self._main_dictionary = json.loads(self.content.decode(self._decode_format))

        return self._main_dictionary

    def __exit__(self, arg1, arg2, arg3):
        self.request.close()

    def __repr__(self):
        return f"Stock price information for {self.ticker} from {self.from_date_dt} to {self.to_date_dt}"

    def _data_processing(self) -> pd.DataFrame:
        """
        Takes the main dictionary read from the yahoo website and prepares for conversion to a dataframe.
        """
        with self as main_info:
            try:
                chart_info = main_info["chart"]
                result_info = chart_info["result"][0]
            except TypeError as e:
                chart_info = main_info["chart"]
                result_info = chart_info["result"]
            except KeyError as e:
                try:
                    chart_info = main_info["finance"]
                    result_info = chart_info["result"]
                    logger.logInfo(
                        f"From {self.from_date_dt} to {self.to_date_dt} 'chart' not valid."
                    )
                except KeyError as ex:
                    logger.logError(
                        f"From {self.from_date_dt} to {self.to_date_dt} 'finance' not valid. Debug"
                    )

        if result_info is None:
            logger.logCritical(
                f"No data for {self.from_date_dt}. Returning Nan dataframe."
            )
            stock_df = self._nan_dataframe(self.from_date_dt)

        else:
            try:
                meta_data = result_info["meta"]

                # Deprecated
                timestamp_info = result_info["timestamp"]
                indicator_info = result_info["indicators"]

                # Pulling price information
                low, high, open, close, volume = self._indicator_reader(indicator_info)

                # Getting the meta data
                (
                    currency,
                    instrument_type,
                    security,
                    gmt_offset,
                    time_zone,
                    exchange_name,
                ) = self._meta_processing(meta_data)

                # Converting timestamp to datetime
                datetime_info = [
                    dt.datetime.fromtimestamp(timestamp) for timestamp in timestamp_info
                ]

                # Creation of headers for dataframe
                stock_info_pre_dataframe = {
                    "asAtDateTime": datetime_info,
                    "marketLow": low,
                    "marketHigh": high,
                    "marketOpen": open,
                    "marketClose": close,
                    "marketVolume": volume,
                }

                stock_df = pd.DataFrame(stock_info_pre_dataframe)
                stock_df["security"] = security
                stock_df["currency"] = currency
                stock_df["instrumentType"] = instrument_type
                stock_df["timeZone"] = time_zone
                stock_df["exchangeName"] = exchange_name
                stock_df["gmtOffSet"] = gmt_offset
            except KeyError as error:
                logger.logCritical(
                    f"No data for {self.from_date_dt}. Returning Nan dataframe."
                )
                stock_df = self._nan_dataframe(self.from_date_dt)

        # Columns ordering
        stock_final_df = self._stock_header_organisation(stock_df).copy()

        return stock_final_df

    @staticmethod
    def _nan_dataframe(date) -> pd.DataFrame:
        stock_info_pre_dataframe = {
            "asAtDateTime": [date],
            "marketLow": [np.nan],
            "marketHigh": [np.nan],
            "marketOpen": [np.nan],
            "marketClose": [np.nan],
            "marketVolume": [np.nan],
        }
        stock_df = pd.DataFrame(stock_info_pre_dataframe)
        stock_df["security"] = np.nan
        stock_df["currency"] = np.nan
        stock_df["instrumentType"] = np.nan
        stock_df["timeZone"] = np.nan
        stock_df["exchangeName"] = np.nan
        stock_df["gmtOffSet"] = np.nan
        return stock_df

    @staticmethod
    def _stock_header_organisation(stock_df: pd.DataFrame) -> pd.DataFrame:
        stock_columns = stock_df.columns
        stock_df = stock_df[
            [
                "asAtDateTime",
                stock_columns[6],
                "currency",
                "marketLow",
                "marketHigh",
                "marketOpen",
                "marketClose",
                "marketVolume",
                "instrumentType",
                "exchangeName",
                "timeZone",
                "gmtOffSet",
            ]
        ]
        return stock_df

    @staticmethod
    def _length_check(main_data: dict) -> bool:
        dataset_lengths = [len(main_data[key]) for key in main_data.keys()]
        lengths = set(dataset_lengths)
        lengths = list(lengths)
        if len(lengths) == 1:
            singular_flag = True
        else:
            singular_flag = False

        return singular_flag

    def _indicator_reader(
        self, indicator_info: dict
    ) -> Tuple[np.array, np.array, np.array, np.array, np.array]:
        """
        Pulls the pricing information, needs a length check
        """
        main_data = indicator_info["quote"][0]

        if self._length_check(main_data):
            pass
        else:
            logger.logError("Dataset has columns of different lengths.")
            raise AttributeError("This dataset has columns of different lengths.")

        market_low = np.float_(main_data["low"])
        market_high = np.float_(main_data["high"])
        market_open = np.float_(main_data["open"])
        market_volume = np.float_(main_data["volume"])
        market_close = np.float_(main_data["close"])

        return (market_low, market_high, market_open, market_close, market_volume)

    @staticmethod
    def _meta_processing(meta_data: dict) -> Tuple[str, str, str, int, str, str]:
        """
        Procceses the meta data.
        """
        try:
            currency = meta_data["currency"]
            inst_type = meta_data["instrumentType"]
            first_trade_date = meta_data["firstTradeDate"]
            security_ticker = meta_data["symbol"]
            gmt_offset = meta_data["gmtoffset"]
            time_zone = meta_data["timezone"]
            exchange_name = meta_data["exchangeName"]

        except KeyError:
            logger.logError("Meta data extraction failed due to KeyError.")

        return (
            currency,
            inst_type,
            security_ticker,
            gmt_offset,
            time_zone,
            exchange_name,
        )

    def getData(self):
        daily_information_df = self._data_processing()
        return daily_information_df


if __name__ == "__main__":
    from_date = dt.datetime(year=2024, day=24, month=5, hour=9)
    to_date = dt.datetime(year=2024, day=24, month=5, hour=17)
    # from_date = round(dt.datetime.timestamp(from_date))
    # to_date = round(dt.datetime.timestamp(to_date))
    ticker = "TSLA"
    url = f"https://query1.finance.yahoo.com/v8/finance/chart/{ticker}?symbol={ticker}&period1={from_date}&period2={to_date}&useYfid=true&interval=1m&includePrePost=true&events=div%7Csplit%7Cearn&lang=en-US&region=US&crumb=azr2X8.O.Sf&corsDomain=finance.yahoo.com"
    StockGrabber(ticker, from_date, to_date).getData()

    string = f"The ticker I am using is {ticker}"
    print(string)

    holder = {"1688641417": "1688814217"}
