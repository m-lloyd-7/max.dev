from py_repo.stock_project.stock_project.stock_stripper import StockGrabber
import pandas as pd
import numpy as np
import datetime as dt
import holidays
import sqlalchemy as db
from sqlalchemy.types import Integer, String, DateTime, Float
from py_max.py_utils.error_logging import ErrorLogger


logger = ErrorLogger(
    __name__,
    "C:/Users/User/dev/max-dev/max_development/stock_project/stock_project/error_logs/stock_stripper_log.log",
)


class DataCapture:
    def __init__(self):
        self.valid_stocks = ["AAPL", "GOOGL", "TSLA", "NVDA", "AMZN", "META", "PYPL"]
        self.end_date_dt = dt.datetime.today().replace(
            hour=0, minute=0, microsecond=0, second=0
        )
        self.start_date_dt = self.end_date_dt - dt.timedelta(days=30)

        self._connection_string = "mssql+pyodbc://DESKTOP-SPUR71A/max_dev?driver=ODBC+Driver+17+for+SQL+Server"
        self._oledb_connection_string = "Provider=SQLOLEDB.1;Integrated Security=SSPI;Persist Security Info=False;Initial Catalog=max_dev;Data Source=DESKTOP-SPUR71A"

    def __enter__(self):
        self.engine = db.create_engine(self._connection_string, echo=False)
        self.connectedEngine = self.engine.connect()
        return self.connectedEngine

    def __exit__(self, exception_type, exception_value, traceback):
        self.connectedEngine.close()
        self.engine.dispose()

    def date_generator(self):
        us_holidays = holidays.US()
        time_delta = self.end_date_dt - self.start_date_dt
        day_iterable_dt = self.start_date_dt
        for day_step in range(time_delta.days):
            day_iterable_dt += dt.timedelta(days=1)
            if (day_iterable_dt in us_holidays) or (
                day_iterable_dt.weekday() in [5, 6]
            ):
                pass
            else:
                yield day_iterable_dt

    def stock_call(self, ticker: str) -> pd.DataFrame:
        stock_timeseries_df = pd.DataFrame()
        for day_dt in self.date_generator():
            start_time = day_dt + dt.timedelta(hours=9)
            end_time = day_dt + dt.timedelta(hours=21)
            stock_df = StockGrabber(ticker, start_time, end_time).getData()
            stock_timeseries_df = pd.concat([stock_timeseries_df, stock_df])
        return stock_timeseries_df

    def insert_to_sql(self, dataframe: pd.DataFrame) -> None:
        dataframe_schema = {
            "asAtDateTime": DateTime,
            "security": String(255),
            "currency": String(255),
            "marketLow": Float,
            "marketHigh": Float,
            "marketOpen": Float,
            "marketClose": Float,
            "marketVolume": Float,
            "instrumentType": String(255),
            "exchangeName": String(255),
            "timeZone": String(255),
            "gmtOffSet": Integer,
        }

        # dataframe["id"] = dataframe.index

        with self as connection:
            dataframe.to_sql(
                "yahooData",
                connection,
                schema="stk",
                index=False,
                if_exists="replace",
                dtype=dataframe_schema,
            )

        logger.logInfo("Successfully written to database.")

    def DataCreation(self, write: bool) -> None:
        all_stock_dataset_df = pd.DataFrame()
        for ticker in self.valid_stocks:
            stock_dataset_df = self.stock_call(ticker)
            logger.logInfo(f"{ticker} information successfully gathered.")
            all_stock_dataset_df = pd.concat([all_stock_dataset_df, stock_dataset_df])

        if write:
            self.insert_to_sql(all_stock_dataset_df)
        else:
            pass


if __name__ == "__main__":
    start_date = "2022-01-01"
    to_date = "2024-05-22"
    DataCapture().DataCreation(write=True)
