import logging


class ErrorLogger:
    def __init__(self, log_name, log_file):
        # Creating main inputs
        self._log_name = log_name
        self._log_file = log_file

        # Creating the logger
        self.logger = logging.getLogger(self._log_name)
        self.logger.setLevel(logging.DEBUG)
        self._file_handler = logging.FileHandler(self._log_file)
        self._formatting = logging.Formatter(
            "[%(asctime)s:%(funcName)s][%(levelname)s]:%(message)s"
        )
        self._file_handler.setFormatter(self._formatting)

        # Extra so we can print out the error statements into the terminal
        self._terminal_handler = logging.StreamHandler()
        self._terminal_handler.setFormatter(self._formatting)

        # Adding the handling for log file and terminal window
        self.logger.addHandler(self._file_handler)
        self.logger.addHandler(self._terminal_handler)

    # Defining a series of class functions that record the error
    def logInfo(self, info_message):
        return self.logger.info(info_message)

    def logDebug(self, debug_message):
        return self.logger.debug(debug_message)

    def logWarning(self, warning_message):
        return self.logger.warning(warning_message)

    def logError(self, error_message):
        return self.logger.error(error_message)

    def logCritical(self, critical_message):
        return self.logger.critical(critical_message)
